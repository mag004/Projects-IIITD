package A3_2020443;
import java.util.*;
import java.util.Random;
public class Dice {
    private final int numFaces;
    private int faceValue;

    public void setFaceValue(int value) {
        if (value <= numFaces) {
            this.faceValue = value;
        }
    }

    public int getFaceValue() {
        return faceValue;
    }

    public int getNumFaces() {
        return numFaces;
    }

    public Dice(int _numFaces){
        numFaces = _numFaces;
        roll();
    }

    public void roll(){
        Random rand = new Random();
        int curr_faceValue = 1 + rand.nextInt(numFaces);
        setFaceValue(curr_faceValue);
    }

}
