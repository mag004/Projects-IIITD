package A3_2020443;

public class Players {
    private String playerName;
//    private int points = 0;

    Floors f = new Floors();
//    private int floorCount;

    public Players(String playerName) {
        this.playerName = playerName;
    }

    public int getPlayerFloorCount() {
        return this.f.getFloorCount();
    }

//    public int getPoints() {
//        return points;
//    }

    public String getPlayerName() {
        return playerName;
    }

//    public void setFloorCount(int floorCount) {
//        this.floorCount = floorCount;
//    }

//    public void setPoints(int points) {
//        this.points += points;
//    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

//    public void setNormalSnakeFloorCount (){
//        this.floorCount = 1;
//    }
//
//    public void setKingCobraFloorCount (){
//        this.floorCount = 3;
//    }
//
//    public void setLadderFloorCount (){
//        this.floorCount = 12;
//    }
//
//    public void setElevatorFloorCount (){
//        this.floorCount = 10;
//    }
    public void setPlayerFloorCount (int floor){
        this.f.setFloorCount(floor);
    }

    public void setDiceFloorCount(int diceFloorCount) {
        this.f.addFloorCount(diceFloorCount);
    }
}
//
//
//
//}
