package A3_2020443;

public class ladderFloor {
}
