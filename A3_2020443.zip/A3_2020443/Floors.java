package A3_2020443;

public class Floors {
    private int floorCount;
    private String ftype;

    public Floors(){
        this.ftype = "Floor";
    }

//    public void emptyFloor(){
//        setPoints(1);
//    }

    public void setFtype(String ftype) {
        this.ftype = ftype;
    }

    public int getFloorCount() {
        return floorCount;
    }

    public String getFtype() {
        return ftype;
    }

    public void setFloorCount(int floorCount) {
        this.floorCount = floorCount;
    }

    public void addFloorCount(int floorCount) {
        this.floorCount += floorCount;
    }



    //    public void normalSnakeFloor(){
//        setPoints(-2);
//    }
//    public void kingCobraFloor(){
//        setPoints(-4);
//    }
//    public void ladderFLoor(){
//        setPoints(2);
//    }
//    public void elevatorFloor(){
//        setPoints(4);
//    }


}
