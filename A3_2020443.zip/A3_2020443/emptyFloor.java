package A3_2020443;

public class emptyFloor extends Floors {
    snakeLadder s = new snakeLadder();
    public emptyFloor(String name , int floor){
        super();
        this.setFloorCount(floor);
        this.setFtype("Empty Floor");
        this.s.setPoints(1);
        System.out.println(name + " has reached an Empty Floor.");

//        System.out.println(this.s.);
    }

}
