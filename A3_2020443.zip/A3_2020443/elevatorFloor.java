package A3_2020443;

public class elevatorFloor extends Floors {
    snakeLadder s = new snakeLadder();

    public elevatorFloor(String playerName , int points , Players a){
        super();
        this.setFtype("Elevator Floor");
        a.setPlayerFloorCount(10);
        this.s.setPoints(4);
        System.out.println(playerName + " has reached an Elevator Floor.");
        System.out.println("Total Points " + (points+4));
        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
        emptyFloor gg = new emptyFloor(playerName , 10);
//        System.out.println("Total Points " + );
    }



}
