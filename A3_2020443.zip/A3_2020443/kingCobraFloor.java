package A3_2020443;

public class kingCobraFloor extends Floors {
    snakeLadder s = new snakeLadder();
    public kingCobraFloor(String name , int points , Players a){
        super();
        this.setFtype("King Cobra Floor");
        a.setPlayerFloorCount(3);
        this.s.setPoints(-4);
        System.out.println(name + " has reached an King Cobra Floor.");
        System.out.println("Total Points " + (points-4));
        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
        emptyFloor gg = new emptyFloor(name , 3);
    }
}
