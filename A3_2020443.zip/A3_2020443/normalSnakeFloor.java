package A3_2020443;

public class normalSnakeFloor extends Floors {
snakeLadder s = new snakeLadder();
    public normalSnakeFloor(String name , int points , Players a){
        super();
        this.setFtype("Normal Snake Floor");
        a.setPlayerFloorCount(1);
        this.s.setPoints(-2);
        System.out.println(name + " has reached an Normal Snake Floor");
        System.out.println("Total Points " + (points-2));
        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
        emptyFloor gg = new emptyFloor(name , 1);
    }
}
