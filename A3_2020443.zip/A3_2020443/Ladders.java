package A3_2020443;

public class Ladders extends Floors {
    snakeLadder s = new snakeLadder();
    public Ladders(String name , int points , Players a){
        super();
        this.setFtype("Ladder Floor");
        a.setPlayerFloorCount(12);
        this.s.setPoints(2);
        System.out.println(name + " has reached an Ladder Floor.");
        System.out.println("Total Points " + (points+2));
        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
        emptyFloor gg = new emptyFloor(name , 12);
    }
}
