package A3_2020443;
import java.util.*;
public class snakeLadder {
private static int points =0;
//private String names;

    public static int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points += points;
    }

//    public static void setNames(String names) {
//        this.names = names;
//    }
//
//    public String getNames() {
//        return names;
//    }

    public static void main(String[] args) {
//        int points = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Player Name and hit Enter");
        String name = sc.nextLine();
        while(name.equals("")){
            System.out.println("No Name Entered");
            System.out.print("Re-Enter the Player Name and hit Enter : ");
            name = sc.nextLine();
        }
//        this.setNames(name);
        Players a = new Players(name);
        System.out.println("The game setup is ready");
        System.out.println("Hit enter to roll the Dice");
        Dice dice = new Dice(2);
        String blank = sc.nextLine();
        dice.roll();

        while (dice.getFaceValue() != 1){
            System.out.println("Dice gave 2");
            System.out.println("Game cannot start until you get 1");
            System.out.println("Hit enter to roll the Dice");
            String b = sc.nextLine();
            dice.roll();
        }
        System.out.println("Dice gave 1");
        System.out.println("Player position Floor-0");
        emptyFloor emf = new emptyFloor(name , 0);
        System.out.println("Total Points " + getPoints());

        while(true){
            Dice dice1 = new Dice(2);
            int x = dice1.getFaceValue();
//            System.out.println(a.getPlayerFloorCount());
            while((a.getPlayerFloorCount() + x) == 14){
                System.out.println("Dice gave 2");
                System.out.println("Can't Move");
                System.out.println("Hit Enter to roll the Dice");
                String blanks = sc.nextLine();
                dice1.roll();
                x=dice1.getFaceValue();
            }


            if (a.getPlayerFloorCount() == 13){
//                System.out.println("Dice Gave " + x);
//                System.out.println("Player position Floor-13");
//                System.out.println(name + " has reached an Empty Floor");

                System.out.println("Total Points :" + getPoints());
                System.out.println("Game Over");
                System.out.println(name + " accumulated " + getPoints() + " Points");
                break;
            }
            System.out.println("Hit Enter to roll the Dice");
            String blanks = sc.nextLine();


            switch(x){
                case 1 :
                    a.setDiceFloorCount(1);
                    System.out.println("Dice gave 1");

                    if (a.getPlayerFloorCount() == 2){
                        System.out.println("Player Position Floor-2");
                        elevatorFloor e = new elevatorFloor(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 5){
                        System.out.println("Player Position Floor-5");
                        normalSnakeFloor n = new normalSnakeFloor(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 8){
                        System.out.println("Player Position Floor-8");
                        Ladders l = new Ladders(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 11){
                        System.out.println("Player Position Floor-11");
                        kingCobraFloor k = new kingCobraFloor(name,points,a);
                    }
                    else{
                        emptyFloor ef = new emptyFloor(name , a.getPlayerFloorCount());
                        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
                    }
                    System.out.println("Total Points " + getPoints());
                    break;

                case 2:
                    a.setDiceFloorCount(2);
                    System.out.println("Dice gave 2");

                    if (a.getPlayerFloorCount() == 2){
                        System.out.println("Player Position Floor-2");
                        elevatorFloor e = new elevatorFloor(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 5){
                        System.out.println("Player Position Floor-5");
                        normalSnakeFloor n = new normalSnakeFloor(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 8){
                        System.out.println("Player Position Floor-8");
                        Ladders l = new Ladders(name,points,a);
                    }
                    else if (a.getPlayerFloorCount() == 11){
                        System.out.println("Player Position Floor-11");
                        kingCobraFloor k = new kingCobraFloor(name,points,a);
                    }
                    else{
                        emptyFloor ef = new emptyFloor(name , a.getPlayerFloorCount());
                        System.out.println("Player Position Floor-" + a.getPlayerFloorCount());
                    }
                    System.out.println("Total Points " + getPoints());
                    break;

            }
        }
    }

}
