import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Main {
    static String randomString()
    {
        int n=4;
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            int index
                    = (int)(AlphaNumericString.length()
                    * Math.random());
            sb.append(AlphaNumericString
                    .charAt(index));
        }
        return sb.toString();
    }
    public static boolean func (Integer rand1 , Integer rand2 , boolean check , Integer division , Scanner sc){
//        Scanner sc = new Scanner(System.in);
        boolean b = true;
        try {
            System.out.println("Calculate the result of " + rand1 + " divided by " + rand2);
            sc.nextLine();
            Integer divans = sc.nextInt();
            sc.nextLine();
            check = divans.equals(division);
            System.out.println("");
        }
        catch (InputMismatchException ime){
            System.out.println("Invalid Format");
//            check = func(rand1,rand2,check,division,sc);
            b = false;
        }
        if (!b) {
            check = func(rand1,rand2,check,division,sc); }
            return check;


    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Bucket bucket = new Bucket();
//        softToy toy = new softToy();
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        Calculator<Object,Object> calculator = new Calculator<>();
        int low = 1;
        int high = 22;
//        int result = r.nextInt(high-low) + low;
        Game game = new Game();
        System.out.println("Enter Player Name : ");
        Player player = new Player(sc.nextLine(),bucket);
        game.setPlayer(player);

        for (int i = 0 ; i<5 ; i++){
            boolean check = false;
            System.out.println("Press Enter for jump "+ (i+1));
            sc.nextLine();
            int result = r.nextInt(high-low) + low;
            System.out.println("You jumped " +result);
            if(result == 21){
                System.out.println("You are too energetic and zoomed past all the tiles. Muddy Puddle Splash!");
                continue;
            }

            if (result%2 == 0){
                try {
                    game.addRewards((softToy) game.getTileArrayList().get(result - 1).getToy().clone());
                    System.out.println("You won a " + game.getTileInfo(result - 1) + " soft toy");
                }
                catch (ArrayIndexOutOfBoundsException aiobe){
                    System.out.println("Cannot access Array element");
                }
                catch(CloneNotSupportedException cnse){
                    System.out.println("Clone Never Happened");
                }
            }
            else{
                while(true) {
                    System.out.println("Question answer round. integer or strings?");
                    String answer = sc.nextLine();
                    try {
                        if (answer.equals("integer")) {
                            Integer rand1 = r.nextInt();
                            Integer rand2 = r.nextInt();
                            Integer division = (Integer) calculator.calc(rand1, rand2);
                            boolean gg = true;
//                            while(gg) {
//
//                                try {
//                                    check = func(rand1,rand2,check,division,sc);
////                                    gg = false;
//                                }
////                                catch (IOException ioe){
////                                    System.out.println("Invalid Input");
////                                }
//                                catch (InputMismatchException ime) {
//                                    System.out.println("Input is in wrong Format");
                                    check = func(rand1,rand2,check,division,sc);
//                                }
//                                break;
//                            }

                            sc.nextLine();
                            break;

                        }
                    }
                    catch (ArithmeticException AE){
                        System.out.println("Invalid Division Format");
                    }

                    if (answer.equals("strings")) {
                        String rand1 = randomString();
                        String rand2 = randomString();
                        String division = (String) calculator.calc(rand1, rand2);
                        System.out.println("Calculate the concatenation of strings " + rand1 + " and " + rand2);
                        String divans = sc.nextLine();
                        check = divans.equals(division);
                        break;
                    }
                    else {
                        System.out.println("Invalid Input");
                    }

                }try {
                    if (check) {
                        System.out.println("Correct Answer");
                        game.addRewards((softToy) game.getTileArrayList().get(result - 1).getToy().clone());
//                        game.getPlayer().getBucket().addItems(game.);
                        System.out.println("You won a " + game.getTileInfo(result-1) + " soft toy");
                    } else {
                        System.out.println("Incorrect Answer");
                        System.out.println("You did not win any soft toy");
                    }
                }
                catch (ArrayIndexOutOfBoundsException aiobe){
                    System.out.println("Cannot access element at the given index");
                }
                catch(CloneNotSupportedException cnse){
                    System.out.println("Clone Never Happened");
                }


            }
        }
        System.out.println("Soft toys won : ");
        System.out.println(game.getPlayer().getBucket());
    }
}
