
public class Calculator<X,Y> {

    public X calc(X x , Y y){
        if (x instanceof String && y instanceof String){
            return (X) (String)((String) x).concat((String)y);
        }
        else if (x instanceof Integer && y instanceof Integer){
            return (X)(Integer)((Integer)x/(Integer)y);
        }

        return null;
    }


}
