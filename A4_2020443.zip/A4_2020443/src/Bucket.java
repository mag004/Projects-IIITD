import java.util.ArrayList;

public class Bucket {

    private ArrayList<softToy> bucketList= new ArrayList<>();

    public void addItems(softToy item) {
        bucketList.add(item);
    }

    @Override
    public String toString() {
        String str = "";
        for (softToy s : this.bucketList){
            str = str.concat(s.getSoftToyName() + " ");
        }
        return str;
    }
}
