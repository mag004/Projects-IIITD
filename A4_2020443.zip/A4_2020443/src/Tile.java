public class Tile{
    private int tileNumber;

    softToy t1;
    public Tile (int tileNumber, String softToyName) throws CloneNotSupportedException {
        this.tileNumber = tileNumber;
        this.t1 = new softToy(softToyName);
    }

    public softToy getToy() {
        return t1;
    }

}
