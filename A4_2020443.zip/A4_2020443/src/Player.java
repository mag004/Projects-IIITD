public class Player {
    private String playerName;
    private Bucket bucket = new Bucket();
    public Player(String playerName,Bucket bucket){
        this.playerName = playerName;
        this.bucket = bucket;
//        Bucket b = new Bucket();
    }


    public Bucket getBucket() {
        return bucket;
    }
}
