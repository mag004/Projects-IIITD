import java.util.ArrayList;
import java.util.Random;
public class Game{
    private int tileNumber;
//    private String playerName;
//    Tile tile = new Tile(tileNumber);
    private ArrayList<Tile> tileArrayList = new ArrayList<>();
    private ArrayList<String> st = new ArrayList<>();
    private Player player;


    public void addRewards (softToy Reward){
        player.getBucket().addItems(Reward);
    }
    public Game() throws CloneNotSupportedException {

        st.add("A");
        st.add("B");
        st.add("C");
        st.add("D");
        st.add("E");
        st.add("F");
        st.add("G");
        st.add("H");
        st.add("I");
        st.add("J");
        st.add("K");
        st.add("L");
        st.add("M");
        st.add("N");
        st.add("O");
        st.add("P");
        st.add("Q");
        st.add("R");
        st.add("S");
        st.add("T");

        for (int i=0 ; i<20 ; i++) {
            tileArrayList.add(new Tile(i+1,st.get(i)));
        }

    }

    public String getTileInfo(int tileNumber){
        return tileArrayList.get(tileNumber).getToy().getSoftToyName();
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public ArrayList<Tile> getTileArrayList() {
        return tileArrayList;
    }
}
