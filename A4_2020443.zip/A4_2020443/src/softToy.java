import java.util.*;
public class softToy implements Cloneable {
//    private ArrayList<String> st;
    private String softToyName;
    public softToy(String softToyName){
        this.softToyName = softToyName;
    }

//    public ArrayList<String> getSt() {
//        return st;
//    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        softToy t = new softToy(this.softToyName);
        return t;
    }

    public String getSoftToyName() {
        return softToyName;
    }
    //    public static softToy getToy(int tileNumber) {
//        return st.get(tileNumber);
//    }
}
