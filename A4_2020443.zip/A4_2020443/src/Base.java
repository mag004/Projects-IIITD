public interface Base {
}
