package AP_A1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class Hospital {
    int unID;
    String Hname;
    int pincode;
    ArrayList<Slots> hospitalSlots;
    public Hospital(String Hname , int pincode , int unID) {
        this.Hname =Hname ;
        this.pincode = pincode;
        this.unID = unID;
        hospitalSlots = new ArrayList<>();
        Map<Integer,Integer> hospitalsByPincode = new HashMap<>();
        Map<Integer , String> hospitalsUNID = new HashMap<>();
        hospitalsByPincode.put(unID , pincode);
        hospitalsUNID.put(unID , Hname);
        System.out.println("Hospital Name : " + this.Hname +" " + "Pincode : " + this.pincode + " " + "Unique Hospital ID : " + unID);
//        unID++;
    }
}