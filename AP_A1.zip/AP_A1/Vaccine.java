package AP_A1;

public class Vaccine {
        String Vname;
        int Vdose;
        int Vgap;
        public Vaccine(String Vname , int Vdose , int Vgap){
            this.Vname = Vname;
            this.Vdose = Vdose;
            this.Vgap =Vgap;
            System.out.println("Vaccine Name : " + this.Vname + " " + "Number of doses required : " + this.Vdose + " " + "Gap between doses : " + this.Vgap);
        }
        public String getname(){
            return Vname;
        }
}
