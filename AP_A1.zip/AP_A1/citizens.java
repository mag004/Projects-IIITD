package AP_A1;

class citizens {
    String Cname;
    int cAge;
    String cID;
    String vac = "";
//    String vac = "";
    int d;
    int dayc;

    public citizens(String Cname , int cAge , String cID) {
        this.Cname = Cname ;
        this.cAge = cAge ;
        this.cID = cID ;
        this.dayc=0;
        System.out.println("Citizen Name : " + this.Cname +" " + "Citizen Age : " + this.cAge + " " + "Citizen Unique ID : " + cID);
    }
}