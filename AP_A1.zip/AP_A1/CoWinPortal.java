package AP_A1;
import java.util.*;
public class CoWinPortal {
    static ArrayList<Vaccine> Vaccines = new ArrayList<>();
    static ArrayList<Hospital> Hospitals = new ArrayList<>();
    static ArrayList<citizens> Citizens = new ArrayList<>();
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Map<Integer,Integer> hospitalsByPincode = new HashMap<>();
        Map<Integer , String> hospitalsUNID = new HashMap<>();
        Map<Integer , String> hospitalsVacc = new HashMap<>();
        Map<String , String> CitizenVacc = new HashMap<>();
        int u = 100000;
        while(true) {
            int slotFlag = 0;
            System.out.println("1.Add Vaccine");
            System.out.println("2.Register Hospital");
            System.out.println("3.Register Citizen");
            System.out.println("4.Add Slot for Vaccination");
            System.out.println("5.Book Slot for Vaccination");
            System.out.println("6.Lists all Slots for a hospital");
            System.out.println("7.Check Vaccination Status");
            System.out.println("8.Exit");
            System.out.println("Enter choice :");
            int choice = sc.nextInt();

            switch (choice){
                case 1:
                    System.out.println("Enter Vaccine Name : ");
                    String VaccName = sc.next();
                    System.out.println("Enter Doses :");
                    int doses = sc.nextInt();
                    System.out.println("Enter Gap :");
                    int gap = sc.nextInt();
                    Vaccine a = new Vaccine(VaccName,doses,gap);
                    Vaccines.add(a);
                    break;
                case 2:
                    System.out.println("Enter Hospital Name : ");
                    String HospName = sc.next();
                    System.out.println("Enter Pincode : ");
                    int pincode = sc.nextInt();
                    Hospital b = new Hospital(HospName, pincode ,u);
                    Hospitals.add(b);

                    hospitalsByPincode.put(b.unID , pincode);
                    hospitalsUNID.put(b.unID , HospName);
                    u++;
                    break;
                case 3:
                    System.out.println("Enter Citizen Name : ");
                    String citizenName = sc.next();
                    System.out.println("Enter Citizen ID : ");
                    String cID = sc.next();
                    System.out.println("Enter Age : ");
                    int age = sc.nextInt();
                    if (age>=18) {
                        citizens c = new citizens(citizenName, age, cID);
                        Citizens.add(c);
                        CitizenVacc.put(cID, "Registered");
                    }
                    else {
                        System.out.println("Under Age");
                    }
                    break;
                case 4:
                    System.out.println("Enter Hospital ID : ");
                    int hospID = sc.nextInt();
                    System.out.println("Enter Number Of Slots : ");
                    int slotNO = sc.nextInt();
                    for (int g = 0 ; g<slotNO ; g++) {
                        System.out.println("Enter Day Number : ");
                        int dayNo = sc.nextInt();
                        System.out.println("Enter Quantity : ");
                        int quantity = sc.nextInt();
                        for (int i = 0; i < Vaccines.size(); i++) {
                            System.out.println(Vaccines.get(i).getname());
//                            System.out.println("\n");
                        }
                        System.out.println("Enter Vaccine Name : ");
                        String VaccineName = sc.next();
                        hospitalsVacc.put(hospID, VaccineName);
                        Slots d = new Slots(hospID, slotNO, dayNo, quantity, VaccineName);
//                    d.Createslots();
                        for (int i = 0; i < Hospitals.size(); i++) {
                            if (Hospitals.get(i).unID == hospID) {
                                Hospitals.get(i).hospitalSlots.add(d);
                                slotFlag = 1;
                                break;
                            }
                        }
                        if (slotFlag == 0) {
                            System.out.println("No such Hospital ID exist");
                        }
                    }
                    break;
                case 5:
                    System.out.println("Enter patient Unique ID : ");
                    String citID = sc.next();
                    int hid= 0;
                    System.out.println("1. Search by Area \n 2. Search by Vaccine \n 3. Exit");
                    System.out.println("Enter Option : ");
                    int option = sc.nextInt();
                    if(option == 1){
                        System.out.println("Enter Pincode :");
                        int pin = sc.nextInt();
                        for (int i=0 ; i<Hospitals.size() ; i++){
                            if (hospitalsByPincode.get(Hospitals.get(i).unID) == pin ){
                                System.out.println(Hospitals.get(i).unID + " " + hospitalsUNID.get(Hospitals.get(i).unID));
                                System.out.println("\n");

                                System.out.println("Enter Hospital ID : ");
                                hid = sc.nextInt();
                                for (int k=0;k<Hospitals.size();k++){
                                    if (Hospitals.get(i).unID == hid){
                                        for (int j=0 ; j<Hospitals.get(i).hospitalSlots.size() ; j++){
                                            System.out.println("Day : " + Hospitals.get(i).hospitalSlots.get(j).day + " " + "Available Quantity :"+ Hospitals.get(i).hospitalSlots.get(j).quantity + " Vaccine :" + Hospitals.get(i).hospitalSlots.get(j).vacc + "\n");
                                        }
                                    }
                                }

                            }

                        }
                        System.out.println("Choose A slot :");
                        int cslot = sc.nextInt();
//                        Hospitals.get(i).hospitalSlots.get(j).quantity--;
                        int i ;
                        for (i = 0 ; i<Hospitals.size() ; i++){
                            if (Hospitals.get(i).unID == hid){
                                break;
                            }

                        }
                        int g;
                        for (g = 0 ; g<Citizens.size() ; g++){
                            if (Citizens.get(g).cID.equals(citID)){
                                Citizens.get(g).vac = Hospitals.get(i).hospitalSlots.get(cslot).vacc;
                                Citizens.get(g).dayc = Hospitals.get(i).hospitalSlots.get(cslot).day;

                                break;
                            }
                        }
                        Hospitals.get(i).hospitalSlots.get(cslot).quantity--;
                        for (int l = 0 ; l <Vaccines.size() ; l++){
                            if (Vaccines.get(l).Vname.equals(Citizens.get(g).vac)){
                                Citizens.get(g).dayc += Vaccines.get(l).Vgap;
                            }
                        }
                        if(Hospitals.get(i).hospitalSlots.get(cslot).quantity <= 0){
                            Hospitals.get(i).hospitalSlots.remove(cslot);
                        }
                        if (CitizenVacc.get(citID) == "Registered"){
                            for (int t=0;t<Citizens.size() ; t++) {
                                if (Citizens.get(t).cID.equals(citID)) {
                                    Citizens.get(t).d = 1;
                                    break;
                                }
                            }
                            CitizenVacc.put(citID , "Partially Vaccinated");
                        }
                        if (CitizenVacc.get(citID) == "Partially Registered"){
                            for (int t=0;t<Citizens.size() ; t++) {
                                if (Citizens.get(t).cID.equals(citID)) {
                                    Citizens.get(t).d = 1;
                                    break;
                                }
                            }
                            CitizenVacc.put(citID , "Fully Vaccinated");
                        }
                        System.out.println(CitizenVacc.get(citID));

                    }
                    if (option == 2){
                        System.out.println("Enter Vaccine Name : ");
                        String v = sc.next();
                        for (int i=0 ; i<Hospitals.size() ; i++) {
                            if (hospitalsVacc.get(Hospitals.get(i).unID).equals(v)) {
                                System.out.println(Hospitals.get(i).unID + " " + hospitalsVacc.get(Hospitals.get(i).unID));
                                System.out.println("\n");

                                System.out.println("Enter Hospital ID : ");
                                hid = sc.nextInt();
                                for (int k=0;k<Hospitals.size();k++){
                                    if (Hospitals.get(i).unID == hid){
                                        for (int j=0 ; j<Hospitals.get(i).hospitalSlots.size() ; j++){
                                            System.out.println("Day : " + Hospitals.get(i).hospitalSlots.get(j).day + " " + "Available Quantity :"+ Hospitals.get(i).hospitalSlots.get(j).quantity + " Vaccine :" + Hospitals.get(i).hospitalSlots.get(j).vacc + "\n");
                                        }
                                    }
                                }
                            }

                        }
                        System.out.println("Choose A slot :");
                        int cslot = sc.nextInt();
                        int i ;
                        for (i = 0 ; i<Hospitals.size() ; i++){
                            if (Hospitals.get(i).unID == hid){
                                break;
                            }

                        }
                        int g;
                        for (g = 0 ; g<Citizens.size() ; g++){
                            if (Citizens.get(g).cID.equals(citID)){
                                Citizens.get(g).vac = Hospitals.get(i).hospitalSlots.get(cslot).vacc;
                                break;
                            }
                        }
                        Hospitals.get(i).hospitalSlots.get(cslot).quantity--;
                        for (int l = 0 ; l <Vaccines.size() ; l++){
                            if (Vaccines.get(l).Vname.equals(Citizens.get(g).vac)){
                                Citizens.get(g).dayc += Vaccines.get(l).Vgap;
                            }
                        }
                        if(Hospitals.get(i).hospitalSlots.get(cslot).quantity <= 0){
                            Hospitals.get(i).hospitalSlots.remove(cslot);
                        }
                        if (CitizenVacc.get(citID) == "Registered"){
                            for (int t=0;t<Citizens.size() ; t++) {
                                if (Citizens.get(t).cID.equals(citID)) {
                                    Citizens.get(t).d = 1;
                                    break;
                                }
                            }
                            CitizenVacc.put(citID , "Partially Vaccinated");
                        }
                        if (CitizenVacc.get(citID) == "Partially Registered"){
                            for (int t=0;t<Citizens.size() ; t++) {
                                if (Citizens.get(t).cID.equals(citID)) {
                                    Citizens.get(t).d = 2;
                                    break;
                                }
                            }
                            CitizenVacc.put(citID , "Fully Vaccinated");
                        }
                        System.out.println(CitizenVacc.get(citID));

                    }
                    if (option == 3){
                        break;
                    }
                    break;
                case 6:
                    System.out.println("Enter Hospital ID : ");
                    int hId = sc.nextInt();
                    for (int i=0;i<Hospitals.size();i++){
                        if (Hospitals.get(i).unID == hId){
                            for (int j=0 ; j<Hospitals.get(i).hospitalSlots.size() ; j++){
                                System.out.println("Day : " + Hospitals.get(i).hospitalSlots.get(j).day + " " + "Available Quantity :"+ Hospitals.get(i).hospitalSlots.get(j).quantity + " Vaccine :" + Hospitals.get(i).hospitalSlots.get(j).vacc + "\n");
                            }
                        }
                    }
                    break;
                case 7:
                    System.out.println("Enter Citizen ID : ");
                    String cid = sc.next();
                    for (int i=0;i<Citizens.size() ; i++) {
                        if (Citizens.get(i).cID.equals(cid)) {

                            System.out.println(CitizenVacc.get(cid));
                            System.out.println("Vaccine Name : " + Citizens.get(i).vac);
                            System.out.println("Number of Doses : " + Citizens.get(i).d);
                            if (Citizens.get(i).d>1) {
                                System.out.println("Due Date :" + Citizens.get(i).dayc);
                            }

                        }

                    }
                    break;

                case 8:
                    return;


            }

//            String VaccName = sc.next();
        }
    }

}
