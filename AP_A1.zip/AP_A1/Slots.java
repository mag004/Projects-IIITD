package AP_A1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Slots {
    int unID;
    int slots;
    int day;
    int quantity;
    String vacc;

    public Slots(int unID, int slots, int day, int quantity, String vacc) {

//        Map<Integer,Slots> hospitalsSlots = new HashMap<>();
//        hospitalsSlots.put(unID,Slots);
        this.unID = unID;
        this.slots = slots;
        this.day = day;
        this.quantity = quantity;
        this.vacc = vacc;
        System.out.println("Slot added by Hospital " + unID + " for Day: " + day + " Available Quantity: " + quantity + " of Vaccine " + vacc);
    }

    public String getVaccine() {
        return vacc;
    }
}
//    }
//    public void bookSlot (int cID) {
//    }
//        public void searchByPincode (int pincode){
//
//        }



