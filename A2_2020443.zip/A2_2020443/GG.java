package A2_2020443;

public interface GG {
    void viewLectures();
    void viewAssessments();
    void viewComments();
    void addComments(int IstID);
//    void Logout();
}
