package A2_2020443;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class lectureSlides {
    private String topic;
    private int noOfSlides;
    private String instructorID;
    private ArrayList<String> contentOfSlides;
    private Date uploadDate;
//    String uploadedBy;

    public void addTopic(String topic){
        this.topic = topic;
    }

    public void addNoOfSlides(int noOfSlides){
        this.noOfSlides = noOfSlides;
    }

    public void addContentOfSlides(ArrayList<String> contentOfSlides){
        this.contentOfSlides = contentOfSlides;
    }

    public void UploadDate(Date uploadDate){
        this.uploadDate = uploadDate;
    }

    public String getTopic() {
        return topic;
    }

    public ArrayList<String> getContentOfSlides() {
        return contentOfSlides;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public int getNoOfSlides() {
        return noOfSlides;
    }

    public String getInstructorID() {
        return instructorID;
    }

    public void setInstructorID(String instructorID) {
        this.instructorID = instructorID;
    }


    //
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter Topic Of Slides : ");
//        String topic = sc.next();
//
//
//    }

}
