package A2_2020443;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
//import java.time.format.DateTimeFormatter;
//import java.time.LocalDateTime;

public class Instructor implements GG {

//    ArrayList<lectureSlides> lectureSlidesArraylist = new ArrayList<>();
//    ArrayList<lectureVideos> lectureVideosArraylist = new ArrayList<>();
//    ArrayList<Assessment> AssessmentArraylist = new ArrayList<>();
    private Backpack bp;
    Map<String , String> InstAssignments = new HashMap<>();
    private String ID;
    public Instructor(Backpack bap , String ID){
        this.bp = bap;
        this.ID= ID;
    }

    public String getID() {
        return ID;
    }

    void uploadLectureSlides(){
        lectureSlides l = new lectureSlides();
        l.setInstructorID(this.ID);
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Topic Of Slides: ");
        String topic = sc.next();
        l.addTopic(topic);
        System.out.println("Enter number of slides: ");
        int noOfSlides = sc.nextInt();
        l.addNoOfSlides(noOfSlides);
        ArrayList<String> tempContentOfSlides = new ArrayList<>();
        for (int i = 0 ; i<noOfSlides ; i++){
            System.out.println("Content of slide: " + (i+1));
            tempContentOfSlides.add(sc.next());
        }
        l.addContentOfSlides(tempContentOfSlides);
//        lectureSlidesArraylist = new ArrayList<>();
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//        LocalDateTime now = LocalDateTime.now();
        java.util.Date date=new java.util.Date();
        l.UploadDate(date);

        this.bp.lectureSlidesArraylist.add(l);
    }

    void uploadLectureVideos(){
        lectureVideos v = new lectureVideos();
        v.setInstructorID(this.ID);
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Topic Of Video: ");
        String topic = sc.next();
        v.addTopicOfVideo(topic);
        System.out.println("Enter Filename Of Video: ");
        String filename = sc.next();
//        String f_name = sc.next();
        int n = filename.length();
        if(n<4 || !filename.substring(n-4,n).equals(".mp4")){
            System.out.println("Incorrect format");
            return;
        }
        else {
            v.addFilenameOfVideo(filename);
        }
        java.util.Date date=new java.util.Date();
        v.UploadDate(date);
//        lectureVideosArraylist = new ArrayList<>();
        this.bp.lectureVideosArraylist.add(v);
    }

    void addAssignment(){
        Assessment a = new Assessment();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Problem Statement: ");
        String problem = sc.nextLine();

        a.addProblemOfAssessment(problem);
        System.out.println("Enter Maximum Marks: ");
        int maxMarks = sc.nextInt();
        a.addMaxMarks(maxMarks);
        this.bp.AssignmentsArraylist.add(a);
        for (int i=0 ; i<this.bp.Student.size() ; i++) {
            this.bp.Student.get(i).studentAssignments.put(problem, "");
            this.bp.Student.get(i).studentAssessmentMarks.put(problem, -1);
            this.bp.Student.get(i).pendingAssignmentsArraylist.add(a);
        }

    }

    void addQuiz(){
        Assessment a = new Assessment();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Quiz Question: ");
        String problem = sc.nextLine();
        a.addProblemOfAssessment(problem);

//        System.out.println("Enter Maximum Marks: ");
        int maxMarks = 1;
        a.addMaxMarks(maxMarks);
        this.bp.QuizArraylist.add(a);
        for (int i=0 ; i<this.bp.Student.size() ; i++) {
            this.bp.Student.get(i).studentAssignments.put(problem, "");
            this.bp.Student.get(i).studentAssessmentMarks.put(problem, -1);
            this.bp.Student.get(i).pendingQuizArraylist.add(a);
        }
    }

    @Override
    public void viewLectures(){
        for (int i = 0 ; i < this.bp.lectureSlidesArraylist.size() ; i++) {
            System.out.println("Title: " + this.bp.lectureSlidesArraylist.get(i).getTopic());
            for (int j = 0 ; j<this.bp.lectureSlidesArraylist.get(i).getContentOfSlides().size() ; j++){
                System.out.println("Slide " + (j+1) + ": " + this.bp.lectureSlidesArraylist.get(i).getContentOfSlides().get(j));
            }
            System.out.println("Number Of Slides: " + this.bp.lectureSlidesArraylist.get(i).getNoOfSlides());
            System.out.println("Date of Upload: " + this.bp.lectureSlidesArraylist.get(i).getUploadDate());
            System.out.println("Uploaded by: " + this.bp.lectureSlidesArraylist.get(i).getInstructorID());
            System.out.println("------------");
        }

        for (int i = 0 ; i < this.bp.lectureVideosArraylist.size() ; i++) {
            System.out.println("Title of Video: " + this.bp.lectureVideosArraylist.get(i).getTopicOfVideo());
            System.out.println("Video file: " + this.bp.lectureVideosArraylist.get(i).getFilenameOfVideo());
            System.out.println("Date of Upload: " + this.bp.lectureVideosArraylist.get(i).getUploadDate());
            System.out.println("Uploaded by: " + this.bp.lectureVideosArraylist.get(i).getInstructorID());
            System.out.println("-----------");
        }
    }

    @Override
    public void viewAssessments(){
        int i =0;
        for (i=0 ; i<this.bp.AssignmentsArraylist.size() ; i++){
            System.out.println("ID: "+ i + " Assignment: " + this.bp.AssignmentsArraylist.get(i).assessmentProblemStatement + "Max Marks: " + this.bp.AssignmentsArraylist.get(i).maxMarks);
        }
        for (int j=0 ; j<this.bp.QuizArraylist.size() ; j++){

            System.out.println("ID: "+ i + " Question: " + this.bp.QuizArraylist.get(j).assessmentProblemStatement );
            i++;
        }
    }

    @Override
    public void addComments(int InstID){
        Scanner sc = new Scanner(System.in);
        Comments c = new Comments();
        System.out.println("Enter Comment: ");
        String tempComment = sc.next();
        c.setCommentStatement(tempComment);
        c.setUser(this.bp.Instructors.get(InstID).getID());
        java.util.Date date=new java.util.Date();
        c.setCommentsDate(date);
        this.bp.commentsArrayList.add(c);

    }

    @Override
    public void viewComments(){
        for (int i = 0 ; i<this.bp.commentsArrayList.size() ; i++){
            System.out.println(this.bp.commentsArrayList.get(i).getCommentStatement() + " - " + this.bp.commentsArrayList.get(i).getUser());
            System.out.println(this.bp.commentsArrayList.get(i).getCommentsDate());
        }
    }












//
//    public static void main(String[] args) {
//    }

}
