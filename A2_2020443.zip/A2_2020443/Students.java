package A2_2020443;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Students implements GG {
    private Backpack bp;
    private String studentID;
    Map<String , String> studentAssignments = new HashMap<>();
    Map<String , Integer> studentAssessmentMarks = new HashMap<>();
    Map<String , String> studentAssessmentGrader = new HashMap<>();
    ArrayList<Assessment> pendingAssignmentsArraylist = new ArrayList<>();
    ArrayList<Assessment> pendingQuizArraylist = new ArrayList<>();

    public Students(Backpack bap , String studentID) {
        this.bp = bap;
        this.studentID = studentID;
    }

    public String getStudentID() {
        return studentID;
    }

    @Override
    public void viewLectures() {
        for (int i = 0; i < this.bp.lectureSlidesArraylist.size(); i++) {
            System.out.println("Title: " + this.bp.lectureSlidesArraylist.get(i).getTopic());
            for (int j = 0; j < this.bp.lectureSlidesArraylist.get(i).getContentOfSlides().size(); j++) {
                System.out.println("Slide " + (j + 1) + ": " + this.bp.lectureSlidesArraylist.get(i).getContentOfSlides().get(j));
            }
            System.out.println("Number Of Slides: " + this.bp.lectureSlidesArraylist.get(i).getNoOfSlides());
            System.out.println("Date of Upload: " + this.bp.lectureSlidesArraylist.get(i).getUploadDate());
            System.out.println("Uploaded by: " + this.bp.lectureSlidesArraylist.get(i).getInstructorID());
        }

        for (int i = 0; i < this.bp.lectureVideosArraylist.size(); i++) {
            System.out.println("Title of Video: " + this.bp.lectureVideosArraylist.get(i).getTopicOfVideo());
            System.out.println("Video file: " + this.bp.lectureVideosArraylist.get(i).getFilenameOfVideo());
            System.out.println("Date of Upload: " + this.bp.lectureVideosArraylist.get(i).getUploadDate());
            System.out.println("Uploaded by: " + this.bp.lectureVideosArraylist.get(i).getInstructorID());
        }
    }

    @Override
    public void viewAssessments() {
        int i = 0;
        for (i = 0; i < this.bp.AssignmentsArraylist.size(); i++) {
            System.out.println("ID: " + i + " Assignment: " + this.bp.AssignmentsArraylist.get(i).assessmentProblemStatement + " Max Marks: " + this.bp.AssignmentsArraylist.get(i).maxMarks);
        }
        for (int j = 0; j < this.bp.QuizArraylist.size(); j++) {
//            i++;
            System.out.println("ID: " + i + " Question: " + this.bp.QuizArraylist.get(j).assessmentProblemStatement);
        i++;
        }
    }

    public void submitAssignments( int stID) {
        Scanner sc = new Scanner((System.in));
        if (this.bp.Student.get(stID).pendingQuizArraylist.size() == 0 && this.bp.Student.get(stID).pendingAssignmentsArraylist.size() == 0) {
            System.out.println("No Pending Assignments");
        }
        else {
            System.out.println("Pending Assessments");

//        for (int i = 0; i < studentAssignments.size(); i++) {
//
//            int j = 0;
//            for (j = 0; j < this.bp.AssignmentsArraylist.size(); j++) {
//                if (studentAssignments.get(this.bp.AssignmentsArraylist.get(j).assessmentProblemStatement).equals("")) {
//                    System.out.println("ID: " + j + "Assignment: " + this.bp.AssignmentsArraylist.get(j).assessmentProblemStatement + "Max Marks: " + this.bp.AssignmentsArraylist.get(j).maxMarks);
//
//                }
//            }
//            for (int k = 0; k < this.bp.QuizArraylist.size(); k++) {
////                j++;
//                if (studentAssignments.get(this.bp.QuizArraylist.get(k).assessmentProblemStatement).equals("")){
//                    System.out.println("ID: " + j + "Question: " + this.bp.QuizArraylist.get(k).assessmentProblemStatement);
//
//                }
//                j++;
//            }
//
//
//        }
////        for (int i =0 ; i<this.bp.Student.get(stID).pendingAssignmentsArraylist.size() ; i++){
////
////        }

            int i = 0;
            for (i = 0; i < this.bp.Student.get(stID).pendingAssignmentsArraylist.size(); i++) {
                System.out.println("ID: " + i + " Assignment: " + this.bp.Student.get(stID).pendingAssignmentsArraylist.get(i).assessmentProblemStatement + " Max Marks: " + this.bp.Student.get(stID).pendingAssignmentsArraylist.get(i).maxMarks);
            }
            for (int j = 0; j < this.bp.Student.get(stID).pendingQuizArraylist.size(); j++) {
//                i++;
                System.out.println("ID: " + i + " Question: " + this.bp.Student.get(stID).pendingQuizArraylist.get(j).assessmentProblemStatement);
                i++;
            }

            System.out.println("Enter ID of assessments: ");
            int assID = sc.nextInt();
            if (assID < this.bp.Student.get(stID).pendingAssignmentsArraylist.size()) {
                System.out.println("Enter filename of Assignment: ");
                String tempFilename = sc.next();
//            String tempFilename = sc.next();
                int n = tempFilename.length();
                if (n<4 || !tempFilename.substring(n - 4, n).equals(".zip")) {
                    System.out.println("Incorrect format");
                    return;
                } else {
                    studentAssignments.put(this.bp.Student.get(stID).pendingAssignmentsArraylist.get(assID).assessmentProblemStatement, tempFilename);
                    this.bp.Student.get(stID).pendingAssignmentsArraylist.remove(assID);
                }
            } else {
                int t = assID - this.bp.Student.get(stID).pendingAssignmentsArraylist.size();
                System.out.println(this.bp.Student.get(stID).pendingQuizArraylist.get(t).assessmentProblemStatement);
                String tempAns = sc.next();
                studentAssignments.put(this.bp.Student.get(stID).pendingQuizArraylist.get(assID).assessmentProblemStatement, tempAns);
                this.bp.Student.get(stID).pendingQuizArraylist.remove(assID);
            }


        }
    }

    @Override
    public void viewComments(){
        for (int i = 0 ; i<this.bp.commentsArrayList.size() ; i++){
            System.out.println(this.bp.commentsArrayList.get(i).getCommentStatement() + " - " + this.bp.commentsArrayList.get(i).getUser());
            System.out.println(this.bp.commentsArrayList.get(i).getCommentsDate());
        }
    }
    @Override
    public void addComments(int studID){
        Scanner sc = new Scanner(System.in);
        Comments c = new Comments();
        System.out.println("Enter Comment: ");
        String tempComment = sc.next();
        c.setCommentStatement(tempComment);
        c.setUser(this.bp.Student.get(studID).getStudentID());
        java.util.Date date=new java.util.Date();
        c.setCommentsDate(date);
        this.bp.commentsArrayList.add(c);

    }

}
