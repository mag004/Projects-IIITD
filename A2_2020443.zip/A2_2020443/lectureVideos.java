package A2_2020443;

import java.util.Date;

public class lectureVideos {
    private String topicOfVideo;
    private String filenameOfVideo;
    private String instructorID;
    private Date uploadDate;
//    String uploadedBy;

    public void addTopicOfVideo(String topicOfVideo) {
        this.topicOfVideo = topicOfVideo;
    }

    public void addFilenameOfVideo(String filenameOfVideo) {
        this.filenameOfVideo = filenameOfVideo;
    }

    public void UploadDate(Date uploadDate){
        this.uploadDate = uploadDate;
    }

    public void setInstructorID(String instructorID) {
        this.instructorID = instructorID;
    }

    public String getInstructorID() {
        return instructorID;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public String getFilenameOfVideo() {
        return filenameOfVideo;
    }

    public String getTopicOfVideo() {
        return topicOfVideo;
    }
}
