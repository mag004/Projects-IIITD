package A2_2020443;
import java.util.Date;
public class Comments {
    private String user;
    private Date commentsDate;
    private String commentStatement;

    public Date getCommentsDate() {
        return commentsDate;
    }

    public String getUser() {
        return user;
    }

    public void setCommentsDate(Date commentsDate) {
        this.commentsDate = commentsDate;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getCommentStatement() {
        return commentStatement;
    }

    public void setCommentStatement(String commentStatement) {
        this.commentStatement = commentStatement;
    }
}
