package A2_2020443;

public class Assessment {
    String assessmentProblemStatement;
    int maxMarks = 1;

    public void addProblemOfAssessment(String assessmentProblemStatement){
        this.assessmentProblemStatement = assessmentProblemStatement;
    }

    public void addMaxMarks(int maxMarks){
        this.maxMarks = maxMarks;
    }


}
