package A2_2020443;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Backpack {

    ArrayList<lectureSlides> lectureSlidesArraylist = new ArrayList<>();
    ArrayList<lectureVideos> lectureVideosArraylist = new ArrayList<>();
    public static ArrayList<Assessment> AssignmentsArraylist = new ArrayList<>();
    public static ArrayList<Assessment> QuizArraylist = new ArrayList<>();
    public static ArrayList<Instructor> Instructors = new ArrayList<>();
    public static ArrayList<Students> Student = new ArrayList<>();
    public static ArrayList<Comments> commentsArrayList = new ArrayList<>();


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Backpack b = new Backpack();
        Instructor I0 = new Instructor(b, "I0");
        Instructor I1 = new Instructor(b, "I1");
        Instructors.add(I0);
        Instructors.add(I1);
        Students S0 = new Students(b, "S0");
        Students S1 = new Students(b, "S1");
        Students S2 = new Students(b, "S2");
        Student.add(S0);
        Student.add(S1);
        Student.add(S2);
        while (true) {
            System.out.println("Welcome to Backpack");
            System.out.println("1. Enter as Instructor");
            System.out.println("2. Enter as Student");
            System.out.println("3. Exit");
            int choice = sc.nextInt();


            switch (choice) {
                case 1:
                    for (int m = 0; m < Instructors.size(); m++) {
                        System.out.println(m + " - " + Instructors.get(m).getID());
                    }

                    int chooseID = sc.nextInt();

                    while (true) {
                        System.out.println("Welcome " + Instructors.get(chooseID).getID());
                        System.out.println("1. Add Class Material");
                        System.out.println("2. Add Assessments");
                        System.out.println("3. View Lecture Materials");
                        System.out.println("4. View Assessments");
                        System.out.println("5. Grade Assessments");
                        System.out.println("6. Close Assessment");
                        System.out.println("7. View Comments");
                        System.out.println("8. Add Comments");
                        System.out.println("9. Logout");

                        int instchoice = sc.nextInt();

//                        switch(instchoice){
                        if (instchoice == 1) {
                            System.out.println("1. Add Lecture Slide");
                            System.out.println("2. Add Lecture Video");
                            int lecChoice = sc.nextInt();
                            if (lecChoice == 1) {
                                Instructors.get(chooseID).uploadLectureSlides();
                            } else if (lecChoice == 2) {
                                Instructors.get(chooseID).uploadLectureVideos();
                            } else {
                                System.out.println("Wrong Selection");
                            }
//                                break;
                        }

                        if (instchoice == 2) {
                            System.out.println("Add Assignment");
                            System.out.println("Add Quiz");
                            int assessChoice = sc.nextInt();
                            if (assessChoice == 1) {
                                Instructors.get(chooseID).addAssignment();
                            } else if (assessChoice == 2) {
                                Instructors.get(chooseID).addQuiz();
                            } else {
                                System.out.println("Wrong Selection");
                            }
//                                break;
                        }

                        if (instchoice == 3) {
                            Instructors.get(chooseID).viewLectures();
//                                break;
                        }

                        if (instchoice == 4) {
                            Instructors.get(chooseID).viewAssessments();
//                                break;
                        }

                        if (instchoice == 5) {
                            if (AssignmentsArraylist.size() == 0 && QuizArraylist.size() == 0) {
                                System.out.println("No Assessments Uploaded");
//                                return;
                            }
                            else{
                                int x = 0;
                            int y = 0;
                            Instructors.get(chooseID).viewAssessments();
                            System.out.println("Enter ID of assessment to view Submissions ");
                            int assessID = sc.nextInt();
                            String tempProblemStatement = "";
                            int tempMaxMarks = 1;
                            System.out.println("Choose ID from these ungraded Submissions");
                            for (int i = 0; i < Student.size(); i++) {

                                if (assessID < AssignmentsArraylist.size()) {
                                    tempProblemStatement = AssignmentsArraylist.get(assessID).assessmentProblemStatement;
                                    tempMaxMarks = AssignmentsArraylist.get(assessID).maxMarks;
                                    if (!Student.get(i).studentAssignments.get(AssignmentsArraylist.get(assessID).assessmentProblemStatement).equals("")) {
                                        System.out.println(i + "." + Student.get(i).getStudentID());
                                    }
                                }
//                                    }
//                                    catch(Exception e){
//                                        continue;
//                                    }

                                if (assessID >= AssignmentsArraylist.size()) {
                                    tempMaxMarks = QuizArraylist.get(assessID - AssignmentsArraylist.size()).maxMarks;
                                    tempProblemStatement = QuizArraylist.get(assessID - AssignmentsArraylist.size()).assessmentProblemStatement;
                                    if (!Student.get(i).studentAssignments.get(QuizArraylist.get(assessID - AssignmentsArraylist.size()).assessmentProblemStatement).equals("")) {
                                        System.out.println(i + "." + Student.get(i).getStudentID());
                                    }
                                }

                            }
                            int studentSubmissionID = sc.nextInt();
                            if (studentSubmissionID > Student.size()) {
                                return;
                            }
                            System.out.println("Submission: " + Student.get(studentSubmissionID).studentAssignments.get(tempProblemStatement));
                            System.out.println("-------------------");
                            System.out.println("Max Marks: " + tempMaxMarks);
                            System.out.println("Enter Marks Scored");
                            int marksScored = sc.nextInt();
                            if (marksScored > tempMaxMarks) {
                                System.out.println("Invalid Marks");
                                return;
                            } else {
                                System.out.println("Marks Score: " + marksScored);
                            }
                            Student.get(studentSubmissionID).studentAssessmentMarks.put(tempProblemStatement, marksScored);
                            Student.get(studentSubmissionID).studentAssessmentGrader.put(tempProblemStatement, Instructors.get(chooseID).getID());
                        }
                        }

                        if (instchoice == 6) {
                            if (AssignmentsArraylist.size() == 0 && QuizArraylist.size() == 0) {
                                System.out.println("No Open Assessments");
                            } else {
                                System.out.println("List of open Assignments: ");
                                int i = 0;
                                for (i = 0; i < AssignmentsArraylist.size(); i++) {
                                    System.out.println("ID: " + i + " Assignment: " + AssignmentsArraylist.get(i).assessmentProblemStatement + "Max Marks: " + AssignmentsArraylist.get(i).maxMarks);
                                }
                                for (int j = 0; j < QuizArraylist.size(); j++) {
//                                    i++;
                                    System.out.println("ID: " + i + " Question: " + QuizArraylist.get(j).assessmentProblemStatement);
                                    i++;
                                }
                                System.out.println("--------------");
                                System.out.println("Enter ID of assignment to close: ");
                                int closeAssID = sc.nextInt();
                                if (closeAssID < AssignmentsArraylist.size()) {

                                    for (int x =0 ; x<Student.size() ; x++){
                                        for (int y =0 ; y<Student.get(x).pendingAssignmentsArraylist.size() ; y++) {
                                            if (Student.get(x).pendingAssignmentsArraylist.get(y).assessmentProblemStatement.equals(AssignmentsArraylist.get(closeAssID).assessmentProblemStatement)){
                                                Student.get(x).pendingAssignmentsArraylist.remove(y);
                                            }
                                        }
                                    }
                                    AssignmentsArraylist.remove(closeAssID);
                                } else {

                                    for (int x =0 ; x<Student.size() ; x++){
                                        for (int y =0 ; y<Student.get(x).pendingQuizArraylist.size() ; y++) {
                                            if (Student.get(x).pendingQuizArraylist.get(y).assessmentProblemStatement.equals(QuizArraylist.get(closeAssID - AssignmentsArraylist.size()).assessmentProblemStatement)){
                                                Student.get(x).pendingQuizArraylist.remove(y);
                                            }
                                        }
                                    }
                                    QuizArraylist.remove(closeAssID - AssignmentsArraylist.size());
                                }


                            }
                        }

                        if (instchoice == 7) {
                            Instructors.get(chooseID).viewComments();
//                                break;
                        }

                        if (instchoice == 8) {
                            Instructors.get(chooseID).addComments(chooseID);
//                                break;
                        }

                        if (instchoice == 9) {
                            break;
                        }


//                        break;

                    }
                    break;

                case 2:
                    for (int m = 0; m < Student.size(); m++) {
                        System.out.println(m + " - " + Student.get(m).getStudentID());
                    }
                    int studID = sc.nextInt();

                    while (true) {
                        System.out.println("Welcome " + Student.get(studID).getStudentID());
                        System.out.println("1. View Lecture Material");
                        System.out.println("2. View Assessments");
                        System.out.println("3. Submit Assessment");
                        System.out.println("4. View Grades");
                        System.out.println("5. View Comments");
                        System.out.println("6. Add Comments");
                        System.out.println("7. Logout");

                        int instChoice = sc.nextInt();

//                        switch (instChoice){
                        if (instChoice == 1) {
                            Student.get(studID).viewLectures();
//                                break;
                        }
                        if (instChoice == 2) {
                            Student.get(studID).viewAssessments();
//                                break;
                        }
                        if (instChoice == 3) {
                            Student.get(studID).submitAssignments(studID);
//                                break;
                        }
                        if (instChoice == 4) {
//                                try {
                            System.out.println("Graded Submissions");
                            for (int i = 0; i < (AssignmentsArraylist.size() + QuizArraylist.size()); i++) {
                                if (i < AssignmentsArraylist.size()) {
                                    if (Student.get(studID).studentAssessmentMarks.get(AssignmentsArraylist.get(i).assessmentProblemStatement) != -1) {
                                        System.out.println("Submission: " + Student.get(studID).studentAssignments.get(AssignmentsArraylist.get(i).assessmentProblemStatement));
                                        System.out.println("Marks Scored: " + Student.get(studID).studentAssessmentMarks.get(AssignmentsArraylist.get(i).assessmentProblemStatement));
                                        System.out.println("Graded by: " + Student.get(studID).studentAssessmentGrader.get(AssignmentsArraylist.get(i).assessmentProblemStatement));
                                    }
                                }
                                System.out.println("---------");
                                if (i >= AssignmentsArraylist.size()) {
                                    if (Student.get(studID).studentAssessmentMarks.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement) != -1) {
                                        System.out.println("Submission: " + Student.get(studID).studentAssignments.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement));
                                        System.out.println("Marks Scored: " + Student.get(studID).studentAssessmentMarks.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement));
                                        System.out.println("Graded by: " + Student.get(studID).studentAssessmentGrader.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement));
                                    }
                                }
                            }
                            System.out.println("---------------");
                            System.out.println("Ungraded Submissions");
                            for (int i = 0; i < (AssignmentsArraylist.size() + QuizArraylist.size()); i++) {
                                if (i < AssignmentsArraylist.size()) {
                                    if (Student.get(studID).studentAssessmentMarks.get(AssignmentsArraylist.get(i).assessmentProblemStatement) == -1) {
                                        System.out.println("Submission: " + Student.get(studID).studentAssignments.get(AssignmentsArraylist.get(i).assessmentProblemStatement));
                                        //                                        System.out.println("Marks Scored: " + Student.get(studID).studentAssessmentMarks.get(AssignmentsArraylist.get(i).assessmentProblemStatement));
                                    }
                                }
                                System.out.println("---------");

                                if (i >= AssignmentsArraylist.size()) {
                                    if (Student.get(studID).studentAssessmentMarks.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement) == -1) {
                                        System.out.println("Submission: " + Student.get(studID).studentAssignments.get(QuizArraylist.get(i - AssignmentsArraylist.size()).assessmentProblemStatement));
                                        //                                        System.out.println("Marks Scored: " + Student.get(studID).studentAssessmentMarks.get(QuizArraylist.get(i).assessmentProblemStatement));
                                    }
                                }
//                                }
//                                catch (Exception exception){
//                                    System.out.println("No Submissions Yet");
//                                }


                            }
                        }

//                                break;
                            if (instChoice == 5) {
                                Student.get(studID).viewComments();
//                                break;
                            }
                            if (instChoice == 6) {
                                Student.get(studID).addComments(studID);
//                                break;
                            }
                            if (instChoice == 7) {
//                                return;
                                break;
                            }


                        }

                        break;

                        case 3:
                            return;


                    }
            }


        }
    }

